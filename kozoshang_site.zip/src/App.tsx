
import React from "react";
import Hero from "./components/Hero";

export default function App() {
  return (
    <div className="w-full min-h-screen">
      <Hero />
    </div>
  );
}
