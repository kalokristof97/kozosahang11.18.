
import React from "react";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="min-h-screen flex items-center justify-center text-center px-8">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
      >
        <h1 className="font-hugin text-6xl text-deepBlue mb-6">
          KözösHang
        </h1>
        <p className="text-xl text-harmonicBlue">
          Közös élmény. Játékosan egyszerű, egyszerűen játékos.
        </p>
      </motion.div>
    </section>
  );
}
