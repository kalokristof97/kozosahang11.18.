
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        deepBlue: "#0A2A43",
        coral: "#EE8469",
        harmonicBlue: "#5C82B7",
        offWhite: "#F7F3EB"
      },
      fontFamily: {
        hugin: ["Hugin", "serif"],
        glacial: ["Glacial", "sans-serif"]
      }
    },
  },
  plugins: [],
}
